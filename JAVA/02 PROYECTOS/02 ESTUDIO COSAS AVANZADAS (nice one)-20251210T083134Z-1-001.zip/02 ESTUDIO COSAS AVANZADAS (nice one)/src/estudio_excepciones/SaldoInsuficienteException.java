package estudio_excepciones;

public class SaldoInsuficienteException extends Exception {
    public SaldoInsuficienteException() {

        super("Saldo insuficiente");
    }

}
