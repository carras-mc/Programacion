package estudio_arrays;

public class Arrays_Unidimensionales {

    public Arrays_Unidimensionales() {

        System.out.println("ARRAYS UNIDIMENSIONALES");
        System.out.println("========================");
        System.out.println(" ");

        
    }

}
