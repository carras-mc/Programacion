package estudio;

public class Ejercicio_Comprobar_DNI {

    public Ejercicio_Comprobar_DNI() {

        // EJERCICIO: tenemos que comprobar un dni
        // si el dni no es valido tira una excepcion
        // comprobar si tiene la cantidad de numeros de un dni y si la letra que tiene puede estar en un dni
        // mod de 23 del dni y dependiendo del resto debe tener una letra u otra
        // extraer del dni la letra

        
    }

}
