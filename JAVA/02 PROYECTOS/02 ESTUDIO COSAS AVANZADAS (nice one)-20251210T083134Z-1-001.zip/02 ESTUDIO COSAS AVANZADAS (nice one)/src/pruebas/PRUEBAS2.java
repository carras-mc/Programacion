package pruebas;

import java.util.Arrays;

public class PRUEBAS2 {

    public PRUEBAS2() {

        int lados = 7;

        for (int l = 1; l <= lados; l++) {

        }
        for (int l = 1; l <= lados; l++) {

        }

    }
}
