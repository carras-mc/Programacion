package excepciones;

public class InvalidISBNException extends Exception {

    public InvalidISBNException() {

        super("InvalidISBNException");
    }

}
